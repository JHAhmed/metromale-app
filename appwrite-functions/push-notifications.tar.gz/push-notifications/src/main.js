import { Client, Users, Messaging, ID } from 'node-appwrite';

// This Appwrite function will be executed every time your function is triggered
export default async ({ req, res, log, error }) => {
	// You can use the Appwrite SDK to interact with other services
	// For this example, we're using the Users service
	const client = new Client()
		.setEndpoint(process.env.APPWRITE_ENDPOINT)
		.setProject(process.env.APPWRITE_PROJECT_ID)
		.setKey(process.env.APPWRITE_API_KEY);

	const users = new Users(client);
	const messaging = new Messaging(client);

	try {
		// const payload = JSON.parse(req);
		const data = req.body;

		const notificationTitle = data.notificationTitle;
		const notificationBody = data.notificationBody;

		await messaging.createPush(ID.unique(), notificationTitle, notificationBody, ['global']);

		log(`Push notification sent`);
	} catch (err) {
		error('Error: ' + err.message, req);
	}

	return res.json({ success: true });
};
